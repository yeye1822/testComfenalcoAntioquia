/* tabla tbl_persons*/
INSERT INTO tbl_persons(document_type, document_number, name, last_name, birth_date, create_date) VALUES('CC', '123456789', 'Jimmy', 'Alvarez', '2018-01-01', '2020-02-22');
INSERT INTO tbl_persons(document_type, document_number, name, last_name, birth_date, create_date) VALUES('CC', '129876023', 'John', 'Alvarez', '2018-01-02', '2020-02-22');
INSERT INTO tbl_persons(document_type, document_number, name, last_name, birth_date, create_date) VALUES('CC', '098765432', 'Camila', 'Alvarez', '2018-01-03', '2020-02-22');
INSERT INTO tbl_persons(document_type, document_number, name, last_name, birth_date, create_date) VALUES('Nit', '15352377', 'Hernan', 'Ocampo', '2018-01-04', '2020-02-22');

/* tabla tbl_InventoryPrize*/
INSERT INTO tbl_inventory_prize(description, amount, create_date) VALUES('Balón Blanco', 3, '2020-02-22');
INSERT INTO tbl_inventory_prize(description, amount, create_date) VALUES('Balón Negro', 1, '2020-02-22');
INSERT INTO tbl_inventory_prize(description, amount, create_date) VALUES('Dulce Blanco', 2, '2020-02-22');