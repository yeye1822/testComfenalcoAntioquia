package co.com.comfenalco.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestProgrammingComfenalcoApplicationTests {

	@Test
	void contextLoads() {
	}

}
